/* AG-develop 12.7.1-649 (2012-09-20 11:43:57 UTC) */
rsinetsegs=[];
if(rsinetsegs.length>0){
var i=1;
var url="//pixel.mathtag.com/event/img?mt_id=153916&mt_adid=106580&no_log=true";
for(var x=1;x<rsinetsegs.length&&url.length<2000;++x){
    if(x>=21){
        url+="&v"+i+"="+rsinetsegs[x];
        i++;}
    else{
            url+="&s"+x+"="+rsinetsegs[x];}
    }
asi_makeGIF(url);}