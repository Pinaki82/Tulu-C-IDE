﻿function PtscriptParseQuery ( query ) {  
   if ( ! query ) return false;
   var Pairs = query.split(/[;&]/);
   var Params = new Object ();
   for ( var i = 0; i < Pairs.length; i++ ) {
      var KeyVal = Pairs[i].split('=');
      if ( ! KeyVal || KeyVal.length != 2 ) continue;
      var key = unescape( KeyVal[0] );
      var val = unescape( KeyVal[1] );
      val = val.replace(/\+/g, ' ');
      Params[key] = val;
   }
   return Params;
}

// retrieve the [SCRIPT OBJ] currently being executed/called

var bhoTrackerPattern = /(mark)[a-z0-9._-]*\.js(\?.*)+$/;
var ptscripts = document.getElementsByTagName('script');
var ptscriptIndex = ptscripts.length - 1;
    
for (sindex=0;sindex<ptscripts.length;sindex++){
        if (ptscripts[sindex].src.match(bhoTrackerPattern)){
            //alert(pscripts[sindex].src);
            ptscriptIndex=sindex;
            break;
        }
    }
    
    
var bhoTrackingScript = ptscripts[ptscriptIndex];
var PtqueryString = bhoTrackingScript.src.replace(/^[^\?]+(\?)*/,'');

var PtscriptParams = PtscriptParseQuery( PtqueryString );

//4831 is the defualt website code
var predictad_working_site = PtscriptParams['si'] || '4831';
var predictad_conv_ad = PtscriptParams['ai'] || '145978';

if (document.images)
    {
      preload_image_object = new Image();
      // set image url
      var x = Math.random();
      var rnd = x * 1000000000000000000;

      image_url = new Array();
      image_url[0] = "http://pixel.predictad.com/trackingPixel/?event=signup&ai="+predictad_conv_ad+"&avi=2001&rnd="+rnd;
      
       var i = 0;
       for(i=0; i<image_url.length; i++) {
            preload_image_object.src = image_url[i];
         }
    }
    
